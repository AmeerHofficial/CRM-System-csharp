﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CRM
{
    public partial class BookDigitalContent : System.Web.UI.Page
    {
        private string connectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            // Get connection string from web.config
            connectionString = ConfigurationManager.ConnectionStrings["CRMConnectionString"].ConnectionString;

            // Check if user is logged in
            if (Session["UserID"] == null)
            {
                // Redirect to login page if not logged in
                Response.Redirect("Login.aspx");
                return;
            }

            if (!IsPostBack)
            {
                // Load available modules on first page load
                LoadAvailableModules();
            }
        }

        private void LoadAvailableModules()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    // SQL to get modules not already booked by the user
                    string query = @"
                        SELECT m.PK_Module_ID, m.Module_Name, m.Description, m.Start_Date, m.End_Date, m.Module_Status

                        FROM Modules m";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@UserID", Session["UserID"]);

                        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                        {
                            DataTable dt = new DataTable();
                            da.Fill(dt);

                            // Bind modules to repeater
                            rptAvailableModules.DataSource = dt;
                            rptAvailableModules.DataBind();

                            // Show/hide message if no modules available
                            if (dt.Rows.Count == 0)
                            {
                                lblBookingMessage.Text = "No new modules are currently available to book.";
                                lblBookingMessage.ForeColor = System.Drawing.Color.Gray;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Log error and show user-friendly message
                lblBookingMessage.Text = "An error occurred while loading modules. Please try again later.";
                lblBookingMessage.ForeColor = System.Drawing.Color.Red;

                // Log the actual error (replace with your logging mechanism)
                System.Diagnostics.Debug.WriteLine($"Module Loading Error: {ex.Message}");
            }
        }

        protected void btnBookSelectedModules_Click(object sender, EventArgs e)
        {
            // List to store selected module IDs
            List<int> selectedModuleIds = new List<int>();

            // Iterate through repeater items to find checked modules
            foreach (RepeaterItem item in rptAvailableModules.Items)
            {
                CheckBox chkModule = (CheckBox)item.FindControl("chkModule");

                if (chkModule != null && chkModule.Checked)
                {
                    int moduleId = Convert.ToInt32(chkModule.Attributes["value"]);
                    selectedModuleIds.Add(moduleId);
                }
            }

            // Check if at least one module is selected
            if (selectedModuleIds.Count > 0)
            {
                // Book selected modules for the current user
                BookModules(selectedModuleIds);
            }
            else
            {
                lblBookingMessage.Text = "Please select at least one module to book.";
                lblBookingMessage.ForeColor = System.Drawing.Color.Red;
            }
        }

        private void BookModules(List<int> selectedModuleIds)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    foreach (int moduleId in selectedModuleIds)
                    {
                        string query = "INSERT INTO UserModules (UserID, ModuleID) VALUES (@UserID, @ModuleID)";
                        using (SqlCommand cmd = new SqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@UserID", Session["UserID"]);
                            cmd.Parameters.AddWithValue("@ModuleID", moduleId);
                            cmd.ExecuteNonQuery();
                        }
                    }

                    lblBookingMessage.Text = "Modules booked successfully!";
                    lblBookingMessage.ForeColor = System.Drawing.Color.Green;

                    // Reload the available modules after booking
                    LoadAvailableModules();
                }
            }
            catch (Exception ex)
            {
                lblBookingMessage.Text = "An error occurred while booking the modules. Please try again.";
                lblBookingMessage.ForeColor = System.Drawing.Color.Red;
                System.Diagnostics.Debug.WriteLine($"Booking Error: {ex.Message}");
            }
        }

        protected void btnDashboard_Click(object sender, EventArgs e)
        {
            Response.Redirect("MemberDashboard.aspx");
        }

        protected void btnViewDigitalContent_Click(object sender, EventArgs e)
        {
            Response.Redirect("ViewDigitalContent.aspx");
        }
    }
}
