﻿
using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace CRM
{
    public partial class ViewDigitalContent : System.Web.UI.Page
    {
        private string connectionString = ConfigurationManager.ConnectionStrings["CRMConnectionString"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            //if (!IsPostBack)
            //{
            //    LoadDigitalModules();
            //}
            // Check if StudentID exists in session
            if (Session["UserID"] == null)
            {
                // If not logged in, redirect to login page
                Response.Redirect("Login.aspx");
            }
            else
            {
                // Retrieve StudentID from session
                int userID = (int)Session["UserID"];

                // Display StudentID in the label

                LoadDigitalModules(userID);
            }
        }


        public void LoadDigitalModules(int userID)
        {
            
            if (userID > 0)
            {
                
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    try
                    {
                        
                        conn.Open();
                        // Query to retrieve events or activities related to the current user
                        string query = @"
SELECT m.PK_Module_ID AS ModuleID, m.Module_Name AS Title, m.Description, 
       m.Event_Type AS CompletionPercentage
FROM Modules m
JOIN UserModules um ON m.PK_Module_ID = um.ModuleID
WHERE um.UserID = @UserID";


                        using (SqlCommand cmd = new SqlCommand(query, conn))
                        {
                            
                            cmd.Parameters.AddWithValue("@UserID", userID);

                            using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                            {
                                DataTable dt = new DataTable();
                                adapter.Fill(dt);

                                // Add debugging output
                                System.Diagnostics.Debug.WriteLine($"Number of rows retrieved: {dt.Rows.Count}");

                                // Optional: Log the actual data
                                foreach (DataRow row in dt.Rows)
                                {
                                    
                                    System.Diagnostics.Debug.WriteLine(
                                        $"ModuleID: {row["ModuleID"]}, " +
                                        $"Title: {row["Title"]}, " +
                                        $"Description: {row["Description"]}, " +
                                        $"CompletionPercentage: {row["CompletionPercentage"]}");
                                }

                                if (dt.Rows.Count > 0)
                                {
                                    //Label1.Text = "UserID: " + userID.ToString();
                                    rptDigitalModules.DataSource = dt;
                                    rptDigitalModules.DataBind();
                                    lblNoModules.Visible = false;
                                }
                                else
                                {
                                    rptDigitalModules.DataSource = null;
                                    rptDigitalModules.DataBind();
                                    lblNoModules.Visible = true;
                                    lblNoModules.Text = "No digital content modules found for this user.";
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        lblNoModules.Text = "An error occurred while loading digital content: " + ex.Message;
                        lblNoModules.Visible = true;
                        // Log full exception details for debugging
                        System.Diagnostics.Debug.WriteLine($"Full Error: {ex.ToString()}");
                    }
                }
            }
            else
            {
                lblNoModules.Text = "User not logged in.";
                lblNoModules.Visible = true;
            }
        }

        protected void btnDashboard_Click(object sender, EventArgs e)
        {
            Response.Redirect("MemberDashboard.aspx");
        }

        protected void btnBookDigitalContent_Click(object sender, EventArgs e)
        {
            Response.Redirect("BookDigitalContent.aspx");
        }

        protected void btnViewModule_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            int moduleID = Convert.ToInt32(btn.CommandArgument);

            // Fetch detailed module information
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = @"
            SELECT 
                m.PK_Module_ID AS ModuleID,
                m.Module_Name AS Title,
                m.Description,
                m.Event_Type AS EventType,
                m.Start_Date AS StartDate,
                m.End_Date AS EndDate,
                m.Module_Status AS ModuleStatus
            FROM Modules m
            WHERE m.PK_Module_ID = @ModuleID";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@ModuleID", moduleID);
                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        // Find the Repeater item
                        RepeaterItem item = (RepeaterItem)((Button)sender).NamingContainer;

                        // Find the details container and labels within the Repeater item
                        HtmlGenericControl detailsDiv = (HtmlGenericControl)item.FindControl("moduleDetails");
                        Label lblStartDate = (Label)item.FindControl("lblStartDate");
                        Label lblEndDate = (Label)item.FindControl("lblEndDate");
                        Label lblModuleStatus = (Label)item.FindControl("lblModuleStatus");
                        Label lblEventType = (Label)item.FindControl("lblEventType");

                        if (detailsDiv != null)
                        {
                            // Populate the labels
                            lblStartDate.Text = Convert.ToDateTime(reader["StartDate"]).ToString("d");
                            lblEndDate.Text = Convert.ToDateTime(reader["EndDate"]).ToString("d");
                            lblModuleStatus.Text = reader["ModuleStatus"].ToString();
                            lblEventType.Text = reader["EventType"].ToString();

                            // Show the details div
                            detailsDiv.Style["display"] = "block";
                        }
                    }
                    else
                    {
                        // Optionally handle case when module details are not found
                        lblNoModules.Text = "Module details not found.";
                        lblNoModules.Visible = true;
                    }
                }
            }
        }





        private int GetCurrentUserId()
        {
            if (Session["UserID"] != null)
            {
                return Convert.ToInt32(Session["UserID"]);
            }
            else
            {
                // Redirect to login if session is empty
                Response.Redirect("Login.aspx");
                return 0; // Will not reach here because of redirect
            }
        }
    }
}
