﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CRM
{
    public partial class UserEventsSearch : System.Web.UI.Page
    {
        private string connectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            // Ensure only admin can access this page
           

            connectionString = ConfigurationManager.ConnectionStrings["CRMConnectionString"].ConnectionString;

            if (!IsPostBack)
            {
                // Load all users and their events on initial page load
                LoadAllUsersAndEvents();
            }
        }

        private void LoadAllUsersAndEvents()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    string query = @"
                        SELECT 
                            u.First_Name, 
                            u.Last_Name, 
                            u.Email, 
                            u.Membership_Type,
                            u.Membership_Status,
                            COALESCE(e.Title, 'No Events') AS Title,
                            COALESCE(e.Location, 'N/A') AS Location,
                            COALESCE(e.Event_Type, 'N/A') AS Event_Type,
                            e.[Date],
                            e.[Time]
                        FROM 
                            [User] u
                        LEFT JOIN 
                            Event1 e ON u.PK_User_ID = e.FK_User_ID
                        ORDER BY 
                            u.Last_Name, u.First_Name, e.[Date]";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                        {
                            DataTable dt = new DataTable();
                            da.Fill(dt);

                            gvUserEvents.DataSource = dt;
                            gvUserEvents.DataBind();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write("An error occurred while loading users: " + ex.Message);
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            string searchTerm = txtUserSearch.Text.Trim();

            if (string.IsNullOrEmpty(searchTerm))
            {
                // If search is empty, reload all users
                LoadAllUsersAndEvents();
                return;
            }

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    // SQL to search for user and their events
                    string query = @"
                        SELECT 
                            u.First_Name, 
                            u.Last_Name, 
                            u.Email, 
	                        u.Membership_Type,
                            u.Membership_Status,
                            COALESCE(e.Title, 'No Events') AS Title,
                            COALESCE(e.Location, 'N/A') AS Location,
                            COALESCE(e.Event_Type, 'N/A') AS Event_Type,
                            e.[Date],
                            e.[Time]
                        FROM 
                            [User] u
                        LEFT JOIN 
                            Event1 e ON u.PK_User_ID = e.FK_User_ID
                        WHERE 
                            u.First_Name LIKE @SearchTerm OR 
                            u.Last_Name LIKE @SearchTerm OR
                            u.Email LIKE @SearchTerm
                        ORDER BY 
                            u.Last_Name, u.First_Name, e.[Date]";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@SearchTerm", "%" + searchTerm + "%");

                        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                        {
                            DataTable dt = new DataTable();
                            da.Fill(dt);

                            gvUserEvents.DataSource = dt;
                            gvUserEvents.DataBind();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Log the error
                // In a real-world scenario, use proper logging
                Response.Write("An error occurred during search: " + ex.Message);
            }
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            // Clear search textbox
            txtUserSearch.Text = string.Empty;

            // Reload all users and events
            LoadAllUsersAndEvents();
        }

        protected void gvUserEvents_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            // Set the new page index
            gvUserEvents.PageIndex = e.NewPageIndex;

            // Reload data based on current search or all users
            string searchTerm = txtUserSearch.Text.Trim();

            if (string.IsNullOrEmpty(searchTerm))
            {
                LoadAllUsersAndEvents();
            }
            else
            {
                btnSearch_Click(sender, e);
            }
        }

        private bool IsUserAdmin()
        {
            // Implement admin authentication
            // This is a placeholder - replace with your actual admin authentication logic
            return Session["UserRole"] != null && Session["UserRole"].ToString() == "Admin";
        }
    }
}