﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

namespace CRM
{
    public partial class SearchMembership : System.Web.UI.Page
    {
  
        private string connectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            // Ensure only admin can access this page


            connectionString = ConfigurationManager.ConnectionStrings["CRMConnectionString"].ConnectionString;

            if (!IsPostBack)
            {
                // Load all users and their events on initial page load
                LoadAllUsersAndEvents();
            }
        }

        private void LoadAllUsersAndEvents()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    string query = @"
                        SELECT 
    u.First_Name + ' ' + u.Last_Name AS Full_Name,
    u.Email,
    m.Membership_Type,
    m.Start_Date,
    m.End_Date
FROM 
    Membership1 m
JOIN 
    [User] u ON m.PK_User_ID = u.PK_User_ID;";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                        {
                            DataTable dt = new DataTable();
                            da.Fill(dt);

                            gvUserEvents.DataSource = dt;
                            gvUserEvents.DataBind();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write("An error occurred while loading users: " + ex.Message);
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            string searchTerm = txtUserSearch.Text.Trim();

            if (string.IsNullOrEmpty(searchTerm))
            {
                // If search is empty, reload all users
                LoadAllUsersAndEvents();
                return;
            }

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    // SQL to search for user and their events
                    string query = @"
                                            SELECT
    u.First_Name + ' ' + u.Last_Name AS Full_Name,
    u.Email,
    m.Membership_Type,
    m.Start_Date,
    m.End_Date
FROM
    Membership1 m
JOIN
    [User] u ON m.PK_User_ID = u.PK_User_ID
                    where m.Membership_Type like @SearchTerm";



                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@SearchTerm", "%" + searchTerm + "%");

                        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                        {
                            DataTable dt = new DataTable();
                            da.Fill(dt);

                            gvUserEvents.DataSource = dt;
                            gvUserEvents.DataBind();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Log the error
                // In a real-world scenario, use proper logging
                Response.Write("An error occurred during search: " + ex.Message);
            }
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            // Clear search textbox
            txtUserSearch.Text = string.Empty;

            // Reload all users and events
            LoadAllUsersAndEvents();
        }

        protected void gvUserEvents_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            // Set the new page index
            gvUserEvents.PageIndex = e.NewPageIndex;

            // Reload data based on current search or all users
            string searchTerm = txtUserSearch.Text.Trim();

            if (string.IsNullOrEmpty(searchTerm))
            {
                LoadAllUsersAndEvents();
            }
            else
            {
                btnSearch_Click(sender, e);
            }
        }

        private bool IsUserAdmin()
        {
            // Implement admin authentication
            // This is a placeholder - replace with your actual admin authentication logic
            return Session["UserRole"] != null && Session["UserRole"].ToString() == "Admin";
        }
    }
}