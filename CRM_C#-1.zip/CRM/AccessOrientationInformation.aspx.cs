﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;

namespace CRM
{
    public partial class AccessOrientationInformation : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Ensure user is logged in
            if (Session["UserID"] == null)
            {
                Response.Redirect("Login.aspx");
                return;
            }

            if (!IsPostBack)
            {
                // Load user's orientation information
                LoadOrientationInformation();
            }
        }

        private void LoadOrientationInformation()
        {
            // Get connection string from web.config
            string connectionString = ConfigurationManager.ConnectionStrings["CRMConnectionString"].ConnectionString;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"
                SELECT 
                    Interest_Category,
                    Specific_Interests,
                    Personal_Goals,
                    Career_Aspirations,
                    Skill_Development_Areas,
                    Preferred_Activities,
                    Long_Term_Objectives,
                    Last_Updated
                FROM 
                    UserInterests
                WHERE 
                    FK_User_ID = @UserID";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Add parameter for current user's ID
                    command.Parameters.AddWithValue("@UserID", Session["UserID"]);

                    try
                    {
                        connection.Open();
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                // Populate read-only fields
                                txtInterestCategory.Text = reader["Interest_Category"].ToString();
                                txtSpecificInterests.Text = reader["Specific_Interests"].ToString();
                                txtPersonalGoals.Text = reader["Personal_Goals"].ToString();
                                txtCareerAspirations.Text = reader["Career_Aspirations"].ToString();
                                txtSkillDevelopment.Text = reader["Skill_Development_Areas"].ToString();
                                txtPreferredActivities.Text = reader["Preferred_Activities"].ToString();
                                txtLongTermObjectives.Text = reader["Long_Term_Objectives"].ToString();

                                // Format and display last updated date
                                DateTime lastUpdated = Convert.ToDateTime(reader["Last_Updated"]);
                                lblLastUpdated.Text = lastUpdated.ToString("dd MMM yyyy HH:mm");
                            }
                            else
                            {
                                // No orientation information found, hide edit button
                                btnEditInfo.Visible = false;
                                lblLastUpdated.Text = "No information available";
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        // Log error (replace with your logging mechanism)
                        lblLastUpdated.Text = "Error retrieving information";
                        // Optionally log the full exception
                        // System.Diagnostics.Debug.WriteLine(ex.ToString());
                    }
                }
            }
        }

        protected void btnEditInfo_Click(object sender, EventArgs e)
        {
            // Switch to edit mode
            pnlOrientationInfo.Visible = false;
            pnlEditInfo.Visible = true;

            // Populate edit fields with current values
            txtEditInterestCategory.Text = txtInterestCategory.Text;
            txtEditSpecificInterests.Text = txtSpecificInterests.Text;
            txtEditPersonalGoals.Text = txtPersonalGoals.Text;
            txtEditCareerAspirations.Text = txtCareerAspirations.Text;
            txtEditSkillDevelopment.Text = txtSkillDevelopment.Text;
            txtEditPreferredActivities.Text = txtPreferredActivities.Text;
            txtEditLongTermObjectives.Text = txtLongTermObjectives.Text;
        }

        protected void btnSaveChanges_Click(object sender, EventArgs e)
        {
            // Get connection string from web.config
            string connectionString = ConfigurationManager.ConnectionStrings["CRMConnectionString"].ConnectionString;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"
                IF EXISTS (SELECT 1 FROM UserInterests WHERE FK_User_ID = @UserID)
                BEGIN
                    UPDATE UserInterests SET
                        Interest_Category = @InterestCategory,
                        Specific_Interests = @SpecificInterests,
                        Personal_Goals = @PersonalGoals,
                        Career_Aspirations = @CareerAspirations,
                        Skill_Development_Areas = @SkillDevelopment,
                        Preferred_Activities = @PreferredActivities,
                        Long_Term_Objectives = @LongTermObjectives,
                        Last_Updated = GETDATE()
                    WHERE FK_User_ID = @UserID
                END
                ELSE
                BEGIN
                    INSERT INTO UserInterests (
                        FK_User_ID,
                        Interest_Category,
                        Specific_Interests,
                        Personal_Goals,
                        Career_Aspirations,
                        Skill_Development_Areas,
                        Preferred_Activities,
                        Long_Term_Objectives,
                        Last_Updated
                    ) VALUES (
                        @UserID,
                        @InterestCategory,
                        @SpecificInterests,
                        @PersonalGoals,
                        @CareerAspirations,
                        @SkillDevelopment,
                        @PreferredActivities,
                        @LongTermObjectives,
                        GETDATE()
                    )
                END";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Add parameters
                    command.Parameters.AddWithValue("@UserID", Session["UserID"]);
                    command.Parameters.AddWithValue("@InterestCategory", txtEditInterestCategory.Text);
                    command.Parameters.AddWithValue("@SpecificInterests", txtEditSpecificInterests.Text);
                    command.Parameters.AddWithValue("@PersonalGoals", txtEditPersonalGoals.Text);
                    command.Parameters.AddWithValue("@CareerAspirations", txtEditCareerAspirations.Text);
                    command.Parameters.AddWithValue("@SkillDevelopment", txtEditSkillDevelopment.Text);
                    command.Parameters.AddWithValue("@PreferredActivities", txtEditPreferredActivities.Text);
                    command.Parameters.AddWithValue("@LongTermObjectives", txtEditLongTermObjectives.Text);

                    try
                    {
                        connection.Open();
                        command.ExecuteNonQuery();

                        // Reload updated information and switch to view mode
                        LoadOrientationInformation();
                        pnlEditInfo.Visible = false;
                        pnlOrientationInfo.Visible = true;
                    }
                    catch (Exception ex)
                    {
                        // Log error
                        lblLastUpdated.Text = "Error saving changes.";
                        // Optionally log the full exception
                        // System.Diagnostics.Debug.WriteLine(ex.ToString());
                    }
                }
            }
        }
        protected void btnCancelEdit_Click(object sender, EventArgs e)
        {
            // Cancel the edit and switch back to view mode
            pnlEditInfo.Visible = false;
            pnlOrientationInfo.Visible = true;
        }

    }
}
