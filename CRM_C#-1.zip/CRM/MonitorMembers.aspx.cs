﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CRM
{
    public partial class MonitorMembers : System.Web.UI.Page
    {

        private string connectionString;

        public MonitorMembers()
        {
            connectionString = ConfigurationManager.ConnectionStrings["CRMConnectionString"].ConnectionString;
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            // Check if the user is an admin
            if (!IsPostBack)
            {
                LoadMemberData();
            }
        }

        private bool IsAdminAuthenticated()
        {
            // Implement your admin authentication logic
            // This could check session variables, authentication cookie, etc.
            return Session["AdminRole"] != null &&
                   Session["AdminRole"].ToString().ToLower() == "admin";
        }

        private void LoadMemberData()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = @"
                    SELECT 
                        u.PK_User_ID AS UserID,
                        u.First_Name + ' ' + u.Last_Name AS FullName,
                        u.Email,
                        u.Membership_Type AS MembershipType,
                        u.Membership_Status,
                        UP.Orientation_Date AS JoinDate,
                        (SELECT COUNT(*) FROM Attendance1 a WHERE a.PK_User_ID = u.PK_User_ID) AS EventsAttended,
                        (SELECT COUNT(*) FROM UserModules um WHERE um.UserID = u.PK_User_ID) AS ModulesCompleted,
                        CASE 
                            WHEN (SELECT COUNT(*) FROM Attendance1 a WHERE a.PK_User_ID = u.PK_User_ID) > 5 THEN 80
                            WHEN (SELECT COUNT(*) FROM Attendance1 a WHERE a.PK_User_ID = u.PK_User_ID) > 2 THEN 50
                            ELSE 20
                        END AS EngagementScore
                    FROM [User] u
                    LEFT JOIN UserInterests UP ON u.PK_User_ID = UP.FK_User_ID
                    WHERE 1=1";

                // Apply membership type filter
                if (!string.IsNullOrEmpty(ddlMembershipType.SelectedValue))
                {
                    query += " AND u.Membership_Type = @MembershipType";
                }

                // Apply date range filter
                int days = Convert.ToInt32(ddlEngagementPeriod.SelectedValue);
                query += " AND UP.Orientation_Date >= DATEADD(day, -@Days, GETDATE())";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    if (!string.IsNullOrEmpty(ddlMembershipType.SelectedValue))
                    {
                        cmd.Parameters.AddWithValue("@MembershipType", ddlMembershipType.SelectedValue);
                    }
                    cmd.Parameters.AddWithValue("@Days", days);

                    conn.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    gvMemberMonitoring.DataSource = dt;
                    gvMemberMonitoring.DataBind();
                }
            }
        }

        protected string GetEngagementScoreClass(int engagementScore)
        {
            if (engagementScore >= 80)
                return "high-engagement";
            else if (engagementScore >= 50)
                return "medium-engagement";
            else
                return "low-engagement";
        }

        protected void ddlMembershipType_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadMemberData();
        }

        protected void ddlEngagementPeriod_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadMemberData();
        }

        protected void gvMemberMonitoring_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvMemberMonitoring.PageIndex = e.NewPageIndex;
            LoadMemberData();
        }

        protected void btnViewDetails_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            int userId = Convert.ToInt32(btn.CommandArgument);

            // Fetch detailed member information
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = @"
                    SELECT 
                        u.PK_User_ID, 
                        u.First_Name + ' ' + u.Last_Name AS FullName,
                        u.Email,
                        u.Membership_Type,
                        u.Membership_Status,
                        UP.Orientation_Date,
                        UP.Interest_Category,
                        UP.Specific_Interests,
                        UP.Personal_Goals,
                        (SELECT COUNT(*) FROM Attendance1 a WHERE a.PK_User_ID = u.PK_User_ID) AS EventsAttended,
                        (SELECT COUNT(*) FROM UserModules um WHERE um.UserID = u.PK_User_ID) AS ModulesCompleted,
                        (SELECT TOP 1 Title FROM Event1 e 
                         JOIN Attendance1 a ON e.PK_Event_ID = a.PK_Event_ID 
                         WHERE a.PK_User_ID = u.PK_User_ID 
                         ORDER BY e.[Date] DESC) AS LastEventAttended
                    FROM [User] u
                    LEFT JOIN UserInterests UP ON u.PK_User_ID = UP.FK_User_ID
                    WHERE u.PK_User_ID = @UserID";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@UserID", userId);
                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        litMemberDetails.Text = $@"
                            <div class='member-profile'>
                                <p><strong>User ID:</strong> {reader["PK_User_ID"]}</p>
                                <p><strong>Full Name:</strong> {reader["FullName"]}</p>
                                <p><strong>Email:</strong> {reader["Email"]}</p>
                                <p><strong>Membership Type:</strong> {reader["Membership_Type"]}</p>
                                <p><strong>Membership Status:</strong> {reader["Membership_Status"]}</p>
                                <p><strong>Joined On:</strong> {Convert.ToDateTime(reader["Orientation_Date"]):d}</p>
                                <p><strong>Interest Category:</strong> {reader["Interest_Category"]}</p>
                                <p><strong>Specific Interests:</strong> {reader["Specific_Interests"]}</p>
                                <p><strong>Personal Goals:</strong> {reader["Personal_Goals"]}</p>
                                <p><strong>Events Attended:</strong> {reader["EventsAttended"]}</p>
                                <p><strong>Modules Completed:</strong> {reader["ModulesCompleted"]}</p>
                                <p><strong>Last Event Attended:</strong> {reader["LastEventAttended"] ?? "No events"}</p>
                            </div>";

                        pnlMemberDetails.Visible = true;
                    }
                    else
                    {
                        litMemberDetails.Text = "<p>Member details not found.</p>";
                        pnlMemberDetails.Visible = false;
                    }
                }
            }
        }
    }
}