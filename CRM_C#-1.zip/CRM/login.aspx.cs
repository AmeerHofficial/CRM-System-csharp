﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CRM
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["CRMConnectionString"].ConnectionString;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // First, check if the email and password match the Administrator table
                string query = "SELECT PK_Admin_ID FROM Administrator WHERE Email = @Email AND Password = @Password";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Email", txtEmail.Text);
                command.Parameters.AddWithValue("@Password", txtPassword.Text);

                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    // If credentials are found in the Administrator table, redirect to AdminDashboard
                    reader.Read();
                    int adminId = reader.GetInt32(0); // Get the Admin ID
                    Session["AdminID"] = adminId; // Store Admin ID in session
                    Response.Redirect("AdminDashboard.aspx", false);
                }
                else
                {
                    // If no match in Administrator table, check the User table
                    reader.Close();
                    query = @"
                        SELECT u.PK_User_ID, ma.Approval_Status
                        FROM [User] u
                        INNER JOIN MemberApproval ma ON u.PK_User_ID = ma.FK_User_ID
                        WHERE u.Email = @Email AND u.Password = @Password";
                    command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@Email", txtEmail.Text);
                    command.Parameters.AddWithValue("@Password", txtPassword.Text);

                    reader = command.ExecuteReader();

                    if (reader.HasRows)
                    {
                        // If credentials are found, check the Approval Status from MemberApproval table
                        reader.Read();
                        int userId = reader.GetInt32(0); // Get the User ID
                        string approvalStatus = reader.GetString(1); // Get the Approval Status

                        if (approvalStatus == "Pending")
                        {
                            // If approval is pending, notify the user and don't allow login
                            ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "alert('Your membership request is pending. Please wait for admin approval.');", true);
                        }
                        else if (approvalStatus == "Rejected")
                        {
                            // If the request was rejected, notify the user and don't allow login
                            ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "alert('Your membership request has been rejected.');", true);
                        }
                        else if (approvalStatus == "Approved")
                        {
                            // If the request is approved, redirect to MemberDashboard
                            Session["UserID"] = userId; // Store User ID in session
                            Response.Redirect("MemberDashboard.aspx?UserID=" + userId, false);
                        }
                    }
                    else
                    {
                        // If no match in either table, display an error message
                        System.Diagnostics.Debug.WriteLine("Login failed");
                        ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "alert('Invalid email or password.');", true);
                    }
                }
                reader.Close();
            }
        }
    }
}
