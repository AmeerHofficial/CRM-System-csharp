﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CRM
{
    public partial class ViewMembershipBenefits : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Check if user is logged in
                if (Session["UserID"] == null)
                {
                    // Redirect to login page if not logged in
                    Response.Redirect("Login.aspx");
                    return;
                }

                // Load user's membership benefits
                LoadMembershipBenefits();
            }
        }

        private void LoadMembershipBenefits()
        {
            // Get connection string from web.config
            string connectionString = ConfigurationManager.ConnectionStrings["CRMConnectionString"].ConnectionString;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // SQL query to fetch membership benefits
                string query = @"
                SELECT 
                    m.Membership_Type AS MembershipType,
                    b.Benefit_Description AS Benefit
                FROM 
                    Membership1 m
                INNER JOIN 
                    MembershipBenefits b
                ON 
                    m.Membership_Type = b.Membership_Type
                WHERE 
                    m.PK_User_ID = @UserID";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Add parameter for current user's ID
                    command.Parameters.AddWithValue("@UserID", Session["UserID"]);

                    try
                    {
                        connection.Open();

                        // Use SqlDataAdapter to fill a DataTable
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);

                        // Check if any benefits found
                        if (dt.Rows.Count > 0)
                        {
                            // Set membership type label
                            lblMembershipType.Text = dt.Rows[0]["MembershipType"].ToString();

                            // Bind benefits to repeater
                            rptBenefits.DataSource = dt;
                            rptBenefits.DataBind();
                        }
                        else
                        {
                            // Handle case where no benefits are found
                            lblMembershipType.Text = "No Membership Type Found";
                            rptBenefits.DataSource = null;
                            rptBenefits.DataBind();
                        }
                    }
                    catch (Exception ex)
                    {
                        // Log the error (replace with your logging mechanism)
                        // You might want to show a user-friendly error message
                        lblMembershipType.Text = "Error retrieving benefits";

                        // Optional: Log the detailed error
                        // Logger.LogError(ex);
                    }
                }
            }
        }
    }
}