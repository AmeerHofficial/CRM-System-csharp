﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CRM
{
    public partial class signup : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSignup_Click(object sender, EventArgs e)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["CRMConnectionString"].ConnectionString;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Begin a transaction to ensure both the User and MemberApproval records are inserted together
                SqlTransaction transaction = connection.BeginTransaction();

                try
                {
                    // Insert into the User table
                    string userQuery = "INSERT INTO [User] (First_Name, Last_Name, Email, Password) OUTPUT INSERTED.PK_User_ID VALUES (@FirstName, @LastName, @Email, @Password)";
                    SqlCommand userCommand = new SqlCommand(userQuery, connection, transaction);
                    userCommand.Parameters.AddWithValue("@FirstName", txtFirstName.Text);
                    userCommand.Parameters.AddWithValue("@LastName", txtLastName.Text);
                    userCommand.Parameters.AddWithValue("@Email", txtEmail.Text);
                    userCommand.Parameters.AddWithValue("@Password", txtPassword.Text);

                    // Retrieve the User ID of the newly inserted user
                    int userId = (int)userCommand.ExecuteScalar();

                    // Insert into the MemberApproval table with 'Pending' status
                    string approvalQuery = "INSERT INTO MemberApproval (FK_User_ID, Approval_Status) VALUES (@UserId, 'Pending')";
                    SqlCommand approvalCommand = new SqlCommand(approvalQuery, connection, transaction);
                    approvalCommand.Parameters.AddWithValue("@UserId", userId);

                    // Execute the command
                    approvalCommand.ExecuteNonQuery();

                    // Commit the transaction
                    transaction.Commit();

                    // Redirect to the login page after successful sign-up
                    Response.Redirect("Login.aspx");
                }
                catch (Exception ex)
                {
                    // Ensure transaction is rolled back only if it hasn't been committed already
                    if (transaction.Connection != null)
                    {
                        transaction.Rollback();
                    }

                    // Log the error for debugging
                    // You can replace this with your preferred logging mechanism
                    Console.WriteLine(ex.Message);

                    ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "alert('Sign-up failed. Please try again.');", true);
                }
            }
        }
    }
}
