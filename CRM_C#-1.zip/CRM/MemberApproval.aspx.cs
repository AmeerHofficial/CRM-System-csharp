﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security; // For secure string handling

namespace CRM
{
    public partial class MemberApproval : System.Web.UI.Page
    {
        private string connectionString;
        private int currentAdminId;

        protected void Page_Load(object sender, EventArgs e)
        {
            // Ensure admin is logged in
            if (!IsUserLoggedInAsAdmin())
            {
                Response.Redirect("Login.aspx");
                return;
            }

            // Get connection string from web.config
            connectionString = ConfigurationManager.ConnectionStrings["CRMConnectionString"].ConnectionString;

            // Get current admin ID from session
            currentAdminId = Convert.ToInt32(Session["AdminID"]);

            if (!IsPostBack)
            {
                try
                {
                    BindMembershipRequests();
                }
                catch (Exception ex)
                {
                    // Log the error
                    HandleError(ex, "Unable to load membership requests.");
                }
            }
        }

        private bool IsUserLoggedInAsAdmin()
        {
            // Implement basic admin authentication
            return Session["AdminID"] != null;
        }

        private void BindMembershipRequests()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = @"
                        SELECT 
                            ma.PK_Approval_ID, 
                            u.First_Name AS UserFirstName, 
                            u.Last_Name AS UserLastName, 
                            u.Email AS UserEmail,
                            ma.Request_Date
                        FROM 
                            MemberApproval ma
                        INNER JOIN 
                            [User] u ON ma.FK_User_ID = u.PK_User_ID
                        WHERE 
                            ma.Approval_Status = 'Pending'
                        ORDER BY 
                            ma.Request_Date DESC";

                    SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    if (dt.Rows.Count > 0)
                    {
                        gvMemberRequests.DataSource = dt;
                        gvMemberRequests.DataBind();

                        // Show/hide empty state
                        pnlNoRequests.Visible = false;
                        gvMemberRequests.Visible = true;
                    }
                    else
                    {
                        // Show empty state
                        pnlNoRequests.Visible = true;
                        gvMemberRequests.Visible = false;
                    }
                }
                catch (SqlException sqlEx)
                {
                    HandleError(sqlEx, "Error loading membership requests.");
                }
            }
        }

        protected void gvMemberRequests_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                // Ensure the command is either Approve or Reject
                if (e.CommandName != "ApproveRequest" && e.CommandName != "RejectRequest")
                    return;

                // Get the Approval ID
                int approvalId = Convert.ToInt32(e.CommandArgument);

                if (e.CommandName == "ApproveRequest")
                {
                    ApproveRequest(approvalId);
                }
                else if (e.CommandName == "RejectRequest")
                {
                    // Show modal for comments
                    ViewState["RejectionApprovalId"] = approvalId;
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "ShowRejectModal",
                        "showRejectModal();", true);
                }
            }
            catch (Exception ex)
            {
                HandleError(ex, "Error processing member request.");
            }
        }

        private void ApproveRequest(int approvalId)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlTransaction transaction = null;

                try
                {
                    transaction = conn.BeginTransaction();

                    // Update Approval Status
                    string approveQuery = @"
                        UPDATE MemberApproval 
                        SET 
                            Approval_Status = 'Approved', 
                            FK_Admin_ID = @AdminId, 
                            Approval_Date = GETDATE() 
                        WHERE 
                            PK_Approval_ID = @ApprovalId 
                            AND Approval_Status = 'Pending';";

                    using (SqlCommand cmd = new SqlCommand(approveQuery, conn, transaction))
                    {
                        cmd.Parameters.AddWithValue("@AdminId", currentAdminId);
                        cmd.Parameters.AddWithValue("@ApprovalId", approvalId);

                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected == 0)
                        {
                            // No rows updated, likely because status changed or approval ID invalid
                            transaction.Rollback();
                            ShowNotification("danger", "Unable to approve request. Request may have already been processed.");
                            return;
                        }
                    }

                    // Commit transaction
                    transaction.Commit();

                    // Show success message
                    ShowNotification("success", "Member request approved successfully!");
                }
                catch (Exception ex)
                {
                    // Rollback transaction
                    if (transaction != null)
                        transaction.Rollback();

                    HandleError(ex, "Error approving member request.");
                }
                finally
                {
                    // Always refresh the grid
                    BindMembershipRequests();
                }
            }
        }

        protected void btnSubmitRejection_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlTransaction transaction = null;

                try
                {
                    transaction = conn.BeginTransaction();

                    // Get the approval ID from ViewState
                    int approvalId = Convert.ToInt32(ViewState["RejectionApprovalId"]);

                    string query = @"
                        UPDATE MemberApproval 
                        SET 
                            Approval_Status = 'Rejected', 
                            FK_Admin_ID = @AdminId, 
                            Approval_Date = GETDATE(),
                            Comments = @Comments
                        WHERE 
                            PK_Approval_ID = @ApprovalId 
                            AND Approval_Status = 'Pending'";

                    using (SqlCommand cmd = new SqlCommand(query, conn, transaction))
                    {
                        cmd.Parameters.AddWithValue("@AdminId", currentAdminId);
                        cmd.Parameters.AddWithValue("@ApprovalId", approvalId);
                        cmd.Parameters.AddWithValue("@Comments",
                            string.IsNullOrWhiteSpace(txtComments.Text) ?
                            "Request rejected without specific comments." :
                            txtComments.Text.Trim());

                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected == 0)
                        {
                            // No rows updated, likely because status changed or approval ID invalid
                            transaction.Rollback();
                            ShowNotification("danger", "Unable to reject request. Request may have already been processed.");
                            return;
                        }
                    }

                    // Commit transaction
                    transaction.Commit();

                    // Show success message
                    ShowNotification("warning", "Member request rejected successfully.");

                    // Clear comments and refresh grid
                    txtComments.Text = string.Empty;
                    BindMembershipRequests();

                    // Hide modal
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "HideRejectModal",
                        "hideRejectModal();", true);
                }
                catch (Exception ex)
                {
                    // Rollback transaction
                    if (transaction != null)
                        transaction.Rollback();

                    HandleError(ex, "Error rejecting member request.");
                }
            }
        }

        private void HandleError(Exception ex, string userMessage = "An error occurred.")
        {
            // Log the error (consider using a proper logging framework)
            System.Diagnostics.Debug.WriteLine($"Error: {ex.Message}");
            System.Diagnostics.Debug.WriteLine($"Stack Trace: {ex.StackTrace}");

            // Show user-friendly error message
            ShowNotification("danger", userMessage);
        }

        private void ShowNotification(string type, string message)
        {
            // Ensure the notification is visible
            lblNotification.CssClass = $"alert alert-{type}";
            lblNotification.Text = message;
            lblNotification.Visible = true;

            // Optional: Add client-side alert for additional visibility
            ScriptManager.RegisterStartupScript(this, this.GetType(), "ShowAlert",
                $"alert('{message}');", true);
        }
    }
}