﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CRM
{
    public partial class AdminDashboard : System.Web.UI.Page
    {
        // Hardcoded connection string for demonstration
        // IMPORTANT: Replace with your actual connection string from web.config
        private string connectionString = @"Data Source=WALEED\SQLEXPRESS;Initial Catalog=CRM;Integrated Security=True;Encrypt=True;TrustServerCertificate=True;";

        protected void Page_Load(object sender, EventArgs e)
        {
            //Label1.Text = "HIIIHIIHIH";
                // Set welcome message
                SetWelcomeMessage();

               
                    // Load Activity Trends
                    LoadActivityTrends();

                    // Load Member Behavior
                    LoadMemberBehavior();
        }


        private void SetWelcomeMessage()
        {
            welcomeMessage.InnerText = $"Welcome, Admin! Today is {DateTime.Now:dddd, MMMM dd, yyyy}";
        }

        private void LoadActivityTrends()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Modified query to handle scenarios where Activity1 table might be empty
                string query = @"
                    SELECT TOP 10 
                        COALESCE(Activity_Name, 'Unnamed Activity') AS Activity_Name, 
                        COALESCE(Activity_Type, 'Unspecified') AS Activity_Type, 
                        COUNT(*) as ActivityCount 
                    FROM Activity1 
                    GROUP BY Activity_Name, Activity_Type 
                    ORDER BY ActivityCount DESC";

                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable dt = new DataTable();

                connection.Open();
                adapter.Fill(dt);

                // Bind data to GridView
                gvActivityTrends.DataSource = dt;
                gvActivityTrends.DataBind();
            }
        }

        private void LoadMemberBehavior()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Ensure proper joins and handle potential null scenarios
                string query = @"
                    SELECT TOP 10 
                        COALESCE(u.First_Name + ' ' + u.Last_Name, 'Unknown User') AS Full_Name,
                        COALESCE(m.Module_Name, 'Unspecified Module') AS Module_Name,
                        COALESCE(m.Event_Type, 'No Event') AS Event_Type,
                        COALESCE(um.BookingDate, GETDATE()) AS BookingDate
                    FROM 
                        UserModules um
                    LEFT JOIN 
                        [User] u ON um.UserID = u.PK_User_ID
                    LEFT JOIN 
                        Modules m ON um.ModuleID = m.PK_Module_ID
                    ORDER BY 
                        um.BookingDate DESC";

                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable dt = new DataTable();

                connection.Open();
                adapter.Fill(dt);

                // Bind data to GridView
                gvMemberBehavior.DataSource = dt;
                gvMemberBehavior.DataBind();
            }
        }

        // Existing button click event handlers remain the same
        protected void btnAddMembers_Click(object sender, EventArgs e)
        {
            Response.Redirect("MemberApproval.aspx");
        }

        protected void btnSearchMembers_Click(object sender, EventArgs e)
        {
            Response.Redirect("UserEventsSearch.aspx");
        }

        protected void btnSearchEvents_Click(object sender, EventArgs e)
        {
            // Placeholder for event search
            Response.Redirect("SpecificEventSearch.aspx");
        }

        protected void btnDifferentiateMemberTYpe_Click(object sender, EventArgs e)
        {
            // Placeholder for member type differentiation
            Response.Redirect("SearchMembership.aspx");
        }

        protected void btnMonitorNewMembers_Click(object sender, EventArgs e)
        {
            // Placeholder for new member monitoring
            Response.Redirect("MonitorMembers.aspx");
        }
    }
}