﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CRM
{
    public partial class MemberDashboard : System.Web.UI.Page
    {
        int userID;
        private string connectionString = ConfigurationManager.ConnectionStrings["CRMConnectionString"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
         

            // Check if UserID is passed in the query string
            if (Request.QueryString["UserID"] != null)
            {
                userID = Convert.ToInt32(Request.QueryString["UserID"]);
                Session["UserID"] = userID; // Optionally store it in session for further pages
            }
            else if (Session["UserID"] == null)
            {
                // Redirect to login if no UserID in query string or session
                Response.Redirect("Login.aspx");
                return;
            }
            else
            {
                // If UserID is in session
                userID = Convert.ToInt32(Session["UserID"]);
            }

            // Proceed with loading membership benefits status
            if (!IsPostBack)
            {
                LoadMembershipBenefitsStatus(userID);
            }
        }


        public void LoadMembershipBenefitsStatus(int userID)
        {
            //int userID = Convert.ToInt32(Session["UserID"]);

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();

                    // Check Digital Content Modules
                    using (SqlCommand cmd = new SqlCommand(
                        "SELECT COUNT(*) FROM Booking b " +
                        "JOIN Event e ON b.PK_Event_ID = e.PK_Event_ID " +
                        "WHERE b.PK_User_ID = @UserID AND e.Event_Type = 'Digital Content'", conn))
                    {
                        cmd.Parameters.AddWithValue("@UserID", userID);
                        int digitalContentCount = Convert.ToInt32(cmd.ExecuteScalar());
                        lblDigitalContentStatus.Text = digitalContentCount > 0
                            ? $"{digitalContentCount} Digital Content Modules Booked"
                            : "No Digital Content Modules Booked";
                    }

                    // Check Orientation Information
                    using (SqlCommand cmd = new SqlCommand(
                        "SELECT COUNT(*) FROM Attendance a " +
                        "JOIN Event e ON a.PK_Event_ID = e.PK_Event_ID " +
                        "WHERE a.PK_User_ID = @UserID AND e.Event_Type = 'Orientation'", conn))
                    {
                        cmd.Parameters.AddWithValue("@UserID", userID);
                        int orientationCount = Convert.ToInt32(cmd.ExecuteScalar());
                        lblOrientationStatus.Text = orientationCount > 0
                            ? $"{orientationCount} Orientation Sessions Attended"
                            : "No Orientation Sessions Attended";
                    }

                    // Check Member Documents
                    using (SqlCommand cmd = new SqlCommand(
                        "SELECT COUNT(*) FROM SearchActivity " +
                        "WHERE FK_User_ID = @UserID AND Query LIKE '%Member Document%'", conn))
                    {
                        cmd.Parameters.AddWithValue("@UserID", userID);
                        int documentSearchCount = Convert.ToInt32(cmd.ExecuteScalar());
                        lblDocumentsStatus.Text = documentSearchCount > 0
                            ? $"{documentSearchCount} Member Document Searches"
                            : "No Member Document Searches";
                    }

                    // Check Connection Boards
                    using (SqlCommand cmd = new SqlCommand(
                        "SELECT COUNT(*) FROM Activity " +
                        "WHERE FK_User_ID = @UserID AND Activity_Type = 'Connection Board'", conn))
                    {
                        cmd.Parameters.AddWithValue("@UserID", userID);
                        int connectionBoardCount = Convert.ToInt32(cmd.ExecuteScalar());
                        lblConnectionBoardsStatus.Text = connectionBoardCount > 0
                            ? $"{connectionBoardCount} Connection Board Activities"
                            : "No Connection Board Activities";
                    }
                }
                catch (Exception ex)
                {
                    // Log the error or show a user-friendly error message
                    lblDigitalContentStatus.Text = "Error loading membership benefits";
                }
            }
        }
        protected void btnViewDigitalContent_Click(object sender, EventArgs e)
        {
            Response.Redirect("ViewDigitalContent.aspx?UserID=" +userID,false);
        }
        protected void btnViewBenefits_Click(object sender, EventArgs e)
        {
            Response.Redirect("ViewMembershipBenefits.aspx?UserID=" + userID, false);
        }


        protected void btnBookDigitalContent_Click(object sender, EventArgs e)
        {
            Response.Redirect("BookDigitalContent.aspx?UserID=" + userID, false);
        }

        protected void btnOrientationInfo_Click(object sender, EventArgs e)
        {
            Response.Redirect("AccessOrientationInformation.aspx?UserID=" + userID, false);
        }

        protected void btnMemberDocs_Click(object sender, EventArgs e)
        {
            Response.Redirect("MemberDocuments.aspx");
        }

        protected void btnConnectionBoards_Click(object sender, EventArgs e)
        {
            Response.Redirect("ConnectionBoards.aspx");
        }

        protected void btnMemberChats_Click(object sender, EventArgs e)
        {
            Response.Redirect("MemberChats.aspx");
        }
    }
}